---
license: mit
title: QuickSave
sdk: docker
emoji: 🚀
colorFrom: blue
colorTo: red
short_description: QuickSave Downloader
pinned: false
---
# quicksave-app